# TRENDYFLY — Content Guide (kaise edit karein)

Poori website ka **saara content ek hi file me hai**:

```
src/data/site.ts
```

Is file ke alawa kisi component ko edit karne ki zarurat nahi — images, text, price,
product sab wahin se badal jaata hai.

---

## 1. Image kaise badlein

1. Apni image `public/images/` folder me daalo.
   Example: `public/images/hero-new.jpg`
2. `src/data/site.ts` me sirf naam likh do:

```ts
mainImage: "images/hero-new.jpg",
```

Image ka size chhota rakho (1600px width, JPG) taake site fast rahe.

## 2. Text kaise badlein

Us section ke neeche jaakar seedha string badal do. Example — hero ka heading:

```ts
title: ["Balance of", "Structure and", "Speed"],
italicWords: ["of", "and"],   // ye words italic me aayenge
```

## 3. Naya product kaise add karein

`products` ki list me ek naya block paste karo (pehle wale product ko copy karke):

```ts
{
  slug: "naya-product-ka-naam",   // page banegi: /product/naya-product-ka-naam
  name: "Naya Product",
  category: "Outerwear",
  collection: "streetwear",        // "streetwear" ya "tailoring"
  price: 500,
  image: "images/p-new.jpg",
  gallery: ["images/p-new.jpg", "images/p-new-2.jpg"],
  colors: [
    { name: "Espresso", hex: "#2A1B14" },
  ],
  sizes: ["46", "48", "50"],
  description: "Yahan product ki detail likho.",
  fabric: "100% wool",
  origin: "Made in Italy",
  featured: true,                  // true = Featured section me dikhega
},
```

## 4. Kisi cheez ko band/hide kaise karein

Us block ke aage `/* ... */` laga do ya poora block delete kar do. Example — collection
band band karna ho to `src/app/page.tsx` se `<CollectionBand />` hata do.

## 5. Kahan kya milta hai (file ka index)

| Section | `src/data/site.ts` me naam |
| --- | --- |
| Brand naam, season | `brand` |
| Menu / navigation | `nav` |
| Hero (top section) | `hero` |
| Collection tiles | `collections` |
| Saare products | `products` |
| Featured Items heading | `featuredItems` |
| Collection band | `collectionBand` |
| Journal / Editorial | `editorial` |
| Footer | `footer` |

## 6. Store kya use karta hai

- **Bag / cart** aur **wishlist** browser ke `localStorage` me save hote hain — refresh ke
  baad bhi rehte hain. Koi database use nahi ho rahi.
- **Checkout** poora browser me chalta hai; order reference (`TF-XXXXXX`) generate hoke
  device par save hota hai. Asli payment integration ke liye Shopify theme
  (`shopify-theme/`) use karo jisme `/cart/add` already wired hai.
- `/api/products` sirf `src/data/site.ts` ka JSON deta hai (search isi ko use karta hai).

## 7. Live chalane ke liye

```bash
npm run dev
```

Build ke liye:

```bash
npm run build
```

---

> **Note:** koi bhi typo ya missing comma ho to build fail hoga — `npm run build` chala kar
> check kar lo. Image ka naam galat ho to image dikhegi nahi (404), isliye file ka naam
> exactly same rakho.
