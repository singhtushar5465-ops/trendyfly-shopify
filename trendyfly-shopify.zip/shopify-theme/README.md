# TRENDYFLY — Shopify Liquid theme (AW26)

Premium menswear storefront: high-end streetwear and professional apparel for the modern man.
The design system is identical to the Next.js storefront in `src/` — warm uncoated paper
(`#F1EDE7`), espresso ink (`#17110E`), leather bands (`#4A2C22`), oxblood accent (`#7E2B1E`),
Archivo grotesque against Bodoni Moda italic.

## Structure

```
layout/theme.liquid            – document shell, fonts, sections
sections/header.liquid         – nav, centred TRENDYFLY mark, Search / Account / Bag (n)
sections/hero.liquid           – split hero, "Balance of Structure and Speed"
sections/collection-tiles.liquid – word tile + floating index list tile (Shopify block based)
sections/featured-items.liquid – staggered "sample lifts out of the plate" product run
sections/collection-band.liquid– full-bleed leather band with COLLECTION + VIEW
sections/editorial.liquid      – "Cut for the City" journal block
sections/footer.liquid         – About Us / Customer Service / Call Us + legal bar
snippets/logo.liquid           – TRENDYFLY vector mark + wordmark
snippets/product-card.liquid   – the pop-out product card
templates/index.json           – homepage section order
templates/collection.liquid    – staggered collection grid
templates/product.liquid       – gallery, swatches, add to bag, spec list
assets/theme.css / theme.js    – design tokens + behaviour
config/settings_schema.json    – brand, colour and type pickers
locales/en.default.json        – copy
```

## Wishlist

`snippets/wishlist-button.liquid` pins a piece (vector heart, oxblood when saved) on every
`product-card`; `sections/wishlist.liquid` + `templates/page.wishlist.json` render the saved list
with **Move to bag**. State lives in `localStorage` (`trendyfly.wishlist.v1`) and is managed by
`assets/theme.js`, with `[data-wishlist-count]` kept in sync in the header.

## Install

```bash
shopify theme push --path shopify-theme --store your-store.myshopify.com
```

Every section ships with an editor schema (`{% schema %}`) so hero copy, imagery, collection
source, product count and footer details are all merchant-editable in the theme customiser.

The featured-items section is the signature block: each product image is pinned to a printed
plate that sits inset behind it, so on hover the sample lifts clear of its frame and casts a
shadow onto the paper — colour chips are pinned outside the plate edge as registration marks.
