/* TRENDYFLY theme behaviour — menu, gallery, wishlist pins. */
(function () {
  var WISHLIST_KEY = "trendyfly.wishlist.v1";

  /* ---- mobile menu ---- */
  var toggle = document.querySelector("[data-menu-toggle]");
  var panel = document.querySelector("[data-menu-panel]");
  if (toggle && panel) {
    toggle.addEventListener("click", function () {
      var open = panel.hasAttribute("hidden");
      if (open) panel.removeAttribute("hidden");
      else panel.setAttribute("hidden", "");
      toggle.setAttribute("aria-expanded", String(open));
      toggle.textContent = open ? "Close" : "Menu";
    });
  }

  /* ---- product gallery ---- */
  var stage = document.querySelector(".product__stage img");
  document.querySelectorAll("[data-thumb]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var img = btn.querySelector("img");
      if (stage && img) stage.src = img.src.replace(/_200\./, "_1400.");
    });
  });

  /* ---- wishlist ---- */
  function readWishlist() {
    try {
      return JSON.parse(window.localStorage.getItem(WISHLIST_KEY) || "[]");
    } catch (e) {
      return [];
    }
  }

  function writeWishlist(items) {
    window.localStorage.setItem(WISHLIST_KEY, JSON.stringify(items));
    document.querySelectorAll("[data-wishlist-count]").forEach(function (el) {
      el.textContent = String(items.length);
    });
  }

  function syncPins() {
    var items = readWishlist();
    document.querySelectorAll("[data-wishlist-pin]").forEach(function (btn) {
      var data;
      try {
        data = JSON.parse(btn.getAttribute("data-product"));
      } catch (e) {
        data = {};
      }
      var saved = items.some(function (i) { return i.slug === data.slug; });
      btn.setAttribute("aria-pressed", String(saved));
    });
  }

  document.addEventListener("click", function (e) {
    var btn = e.target.closest ? e.target.closest("[data-wishlist-pin]") : null;
    if (!btn) return;
    e.preventDefault();
    var data;
    try {
      data = JSON.parse(btn.getAttribute("data-product"));
    } catch (err) {
      return;
    }
    var items = readWishlist();
    var exists = items.some(function (i) { return i.slug === data.slug; });
    items = exists
      ? items.filter(function (i) { return i.slug !== data.slug; })
      : items.concat([data]);
    writeWishlist(items);
    syncPins();
  });

  /* ---- wishlist page rendering ---- */
  var mount = document.querySelector("[data-wishlist-mount]");
  if (mount) {
    var items = readWishlist();
    if (items.length === 0) {
      mount.innerHTML = '<p class="display wishlist__empty">Nothing pinned yet. Tap the heart on any piece to pin it here.</p>';
    } else {
      mount.innerHTML = items
        .map(function (i) {
          return (
            '<div class="wishlist__row">' +
            '<a href="' + i.url + '"><img src="' + i.image + '" alt=""></a>' +
            '<div class="wishlist__meta">' +
            '<span class="label text-stone">' + (i.type || "AW26") + "</span>" +
            '<a class="link-underline" href="' + i.url + '"><strong>' + i.title + "</strong></a>" +
            '<p class="num">' + (i.price / 100).toFixed(0) + "</p>" +
            "</div>" +
            '<form method="post" action="/cart/add">' +
            '<input type="hidden" name="id" value="' + i.slug + '">' +
            '<button type="submit" class="btn-block">Move to bag</button>' +
            "</form>" +
            '<button type="button" class="label pin" data-wishlist-pin ' +
            "data-product='" + JSON.stringify(i) + "' aria-pressed=\"true\">Remove</button>" +
            "</div>"
          );
        })
        .join("");
    }
    syncPins();
  }

  writeWishlist(readWishlist());
  syncPins();
})();
