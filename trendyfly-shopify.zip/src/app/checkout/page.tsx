import { CheckoutForm } from "@/components/CheckoutForm";

export const dynamic = "force-dynamic";

export default function CheckoutPage() {
  return (
    <div className="px-4 py-16 md:px-10 md:py-20">
      <div className="mx-auto max-w-[1600px]">
        <CheckoutForm />
      </div>
    </div>
  );
}
