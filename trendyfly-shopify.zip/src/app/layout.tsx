import type { Metadata } from "next";
import type { ReactNode } from "react";
import { CartProvider } from "@/components/CartProvider";
import { Footer } from "@/components/Footer";
import { Header } from "@/components/Header";
import { WishlistProvider } from "@/components/WishlistProvider";
import "./globals.css";

export const metadata: Metadata = {
  title: "TRENDYFLY — Streetwear & Tailoring for the Modern Man",
  description:
    "TRENDYFLY designs high-end streetwear and professional apparel for the modern man. AW26 — balance of structure and speed.",
  icons: { icon: "/favicon.svg" },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700;800;900&family=Bodoni+Moda:ital,wght@0,400;0,500;0,700;0,900;1,400;1,500&display=swap"
        />
      </head>
      <body className="min-h-screen bg-paper text-ink antialiased">
        <CartProvider>
          <WishlistProvider>
            <Header />
            <main>{children}</main>
            <Footer />
          </WishlistProvider>
        </CartProvider>
      </body>
    </html>
  );
}
