import Link from "next/link";
import { SampleCard } from "@/components/SampleCard";
import { collections, getCollection, productsByCollection } from "@/data/site";

export default async function ShopPage({
  searchParams,
}: {
  searchParams: Promise<{ c?: string }>;
}) {
  const { c } = await searchParams;
  const active = c && c !== "all" ? c : "all";
  const activeCollection = getCollection(active);
  const list = productsByCollection(active);

  const tabs = [{ slug: "all", name: "All Pieces" }, ...collections];

  return (
    <div className="px-4 pt-10 pb-24 md:px-10">
      <div className="mx-auto max-w-[1600px]">
        <span className="label text-stone">AW26 — Collection</span>
        <div className="mt-4 grid gap-6 md:grid-cols-[minmax(0,1fr)_minmax(0,1fr)] md:items-end">
          <h1 className="slab text-[clamp(3rem,9vw,7.5rem)]">
            {activeCollection ? activeCollection.name : "All Pieces"}
          </h1>
          <p className="max-w-[46ch] text-sm leading-relaxed text-stone md:justify-self-end">
            {activeCollection
              ? activeCollection.blurb
              : "High-end streetwear and professional apparel for the modern man. Cut from the same block — the cloth is the only thing that changes."}
          </p>
        </div>

        <nav className="mt-8 flex flex-wrap gap-2 border-t hairline pt-6">
          {tabs.map((t) => (
            <Link
              key={t.slug}
              href={t.slug === "all" ? "/shop" : `/shop?c=${t.slug}`}
              className={`label focusable border px-5 py-3 transition-colors ${
                active === t.slug
                  ? "border-ink bg-ink text-paper-2"
                  : "hairline border hover:border-ink"
              }`}
            >
              {t.name}
            </Link>
          ))}
        </nav>

        <div className="mt-14 grid grid-cols-4 gap-x-5 gap-y-16 md:gap-x-8 lg:grid-cols-12">
          {list.map((p, i) => (
            <SampleCard key={p.slug} product={p} index={i} staggered={false} />
          ))}
        </div>

        {list.length === 0 ? (
          <p className="display py-24 text-center text-3xl italic">
            Nothing in this collection yet.
          </p>
        ) : null}
      </div>
    </div>
  );
}
