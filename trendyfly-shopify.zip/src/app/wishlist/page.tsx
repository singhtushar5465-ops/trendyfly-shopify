import { WishlistView } from "@/components/WishlistView";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Wishlist — TRENDYFLY",
  description: "Pieces you pinned at TRENDYFLY: high-end streetwear and tailoring for the modern man.",
};

export default function WishlistPage() {
  return (
    <div className="px-4 pt-10 pb-24 md:px-10">
      <div className="mx-auto max-w-[1600px]">
        <span className="label text-stone">Wishlist — AW26</span>
        <div className="mt-4 grid gap-6 md:grid-cols-[minmax(0,1fr)_minmax(0,1fr)] md:items-end">
          <h1 className="slab text-[clamp(3rem,9vw,7.5rem)]">Wishlist</h1>
          <p className="max-w-[46ch] text-sm leading-relaxed text-stone md:justify-self-end">
            Everything you pinned, kept in one place. Saved on this device — move a piece to the bag
            whenever you are ready.
          </p>
        </div>
        <div className="mt-8" />
        <WishlistView />
      </div>
    </div>
  );
}
