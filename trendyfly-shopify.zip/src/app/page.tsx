import { CollectionBand } from "@/components/CollectionBand";
import { CollectionTiles } from "@/components/CollectionTiles";
import { Editorial } from "@/components/Editorial";
import { FeaturedItems } from "@/components/FeaturedItems";
import { Hero } from "@/components/Hero";
import { WishlistSection } from "@/components/WishlistSection";
import { collections, featuredProducts } from "@/data/site";

export default function HomePage() {
  return (
    <>
      <Hero />
      <CollectionTiles collections={collections} />
      <FeaturedItems products={featuredProducts()} />
      <CollectionBand />
      <WishlistSection fallback={featuredProducts()} />
      <Editorial />
    </>
  );
}
