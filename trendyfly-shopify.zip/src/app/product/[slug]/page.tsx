import Link from "next/link";
import { notFound } from "next/navigation";
import { ProductView } from "@/components/ProductView";
import { SampleCard } from "@/components/SampleCard";
import { getProduct, relatedProducts } from "@/data/site";

export default async function ProductPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const product = getProduct(slug);
  if (!product) notFound();
  const related = relatedProducts(product.slug, 3);

  return (
    <div className="px-4 pt-8 pb-24 md:px-10">
      <div className="mx-auto max-w-[1600px]">
        <div className="label mb-8 flex gap-3 text-stone">
          <Link href="/" className="focusable link-underline">
            Home
          </Link>
          <span>/</span>
          <Link href="/shop" className="focusable link-underline">
            Shop
          </Link>
          <span>/</span>
          <span className="text-ink">{product.name}</span>
        </div>

        <ProductView product={product} />

        <section className="mt-24">
          <div className="flex items-end justify-between">
            <h2 className="slab text-[clamp(2rem,5vw,3.6rem)]">Also Cut</h2>
            <Link href="/shop" className="focusable label-lg link-underline">
              See All ↗
            </Link>
          </div>
          <div className="mt-10 grid grid-cols-4 gap-x-5 gap-y-14 md:gap-x-8 lg:grid-cols-12">
            {related.map((p, i) => (
              <SampleCard key={p.slug} product={p} index={i + 1} staggered={false} />
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
