import Link from "next/link";
import { SampleCard } from "@/components/SampleCard";
import { searchProducts } from "@/data/site";

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const { q } = await searchParams;
  const term = (q ?? "").trim();
  const results = searchProducts(term);

  return (
    <div className="px-4 pt-10 pb-24 md:px-10">
      <div className="mx-auto max-w-[1600px]">
        <span className="label text-stone">Search — AW26</span>
        <div className="mt-4 grid gap-6 md:grid-cols-[minmax(0,1fr)_minmax(0,1fr)] md:items-end">
          <h1 className="slab break-words text-[clamp(2.4rem,8vw,6.5rem)]">
            {term ? `“${term}”` : "All Pieces"}
          </h1>
          <p className="max-w-[46ch] text-sm leading-relaxed text-stone md:justify-self-end">
            {results.length} {results.length === 1 ? "piece" : "pieces"} matched your search. High-end
            streetwear and professional apparel for the modern man.
          </p>
        </div>

        <nav className="mt-8 flex flex-wrap gap-2 border-t hairline pt-6">
          <Link href="/shop" className="label focusable hairline border px-5 py-3 hover:border-ink">
            Back to shop
          </Link>
          <Link
            href="/shop?c=streetwear"
            className="label focusable hairline border px-5 py-3 hover:border-ink"
          >
            Streetwear
          </Link>
          <Link
            href="/shop?c=tailoring"
            className="label focusable hairline border px-5 py-3 hover:border-ink"
          >
            Tailoring
          </Link>
        </nav>

        {results.length === 0 ? (
          <div className="py-24 text-center">
            <p className="display text-3xl italic">Nothing matches “{term}”.</p>
            <p className="mt-4 text-sm text-stone">Try leather, wool, blazer or trouser.</p>
          </div>
        ) : (
          <div className="mt-14 grid grid-cols-4 gap-x-5 gap-y-16 md:gap-x-8 lg:grid-cols-12">
            {results.map((p, i) => (
              <SampleCard key={p.slug} product={p} index={i} staggered={false} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
