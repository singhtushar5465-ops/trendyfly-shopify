import { NextResponse } from "next/server";
import { collections, products, productsByCollection, searchProducts } from "@/data/site";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const collection = searchParams.get("collection") ?? undefined;
  const q = searchParams.get("q");

  const list = q != null ? searchProducts(q) : productsByCollection(collection);

  return NextResponse.json({ collections, products: list }, { status: 200 });
}
