/* ============================================================================
   TRENDYFLY — SITE CONTENT
   ----------------------------------------------------------------------------
   Ye ek hi file hai jisme poori website ka content hai. Images badalni ho ya
   text badalni ho — SIRF is file ko edit karo, baaki code ko haath lagane ki
   zarurat nahi.

   • Images: apni file `public/images/` folder me daalo, aur neeche sirf naam
     likho.  Example:  image: "images/hero-main.jpg"
   • Text: bas string badal do.
   • Naya product add karna: neeche `products` ki list me ek naya block paste
     karo (niche ka pehla product ko copy karke banao).
   • Kisi cheez ko band karna: uss block ke aage `//` laga do ya hata do.
============================================================================ */

/* ---------------------------------------------------------------------------
   1. BRAND + NAVIGATION
--------------------------------------------------------------------------- */
export const brand = {
  name: "TRENDYFLY",
  tagline: "Streetwear & Tailoring for the Modern Man",
  season: "AW26",
  announcement: "Complimentary express shipping on all AW26 orders",
};

export const nav = [
  { label: "New In", href: "/shop" },
  { label: "Streetwear", href: "/shop?c=streetwear" },
  { label: "Tailoring", href: "/shop?c=tailoring" },
  { label: "Journal", href: "/#editorial" },
];

/* ---------------------------------------------------------------------------
   2. HERO  (top wala section)
   title_html me <em> ... </em> italic dikhata hai.
--------------------------------------------------------------------------- */
export const hero = {
  season: "AW26 — Collection 01",
  origin: "London · Made in Europe",
  title: ["Balance of", "Structure and", "Speed"],
  italicWords: ["of", "and"], // ye words italic me aayenge
  ctaLabel: "Discover Collection",
  ctaHref: "/shop",
  mainImage: "images/hero-main.jpg", // bada panel
  sideImage: "images/hero-detail.jpg", // chhota panel
  sideNote: "Leather, wool, wax. Nothing decorative.",
};

/* ---------------------------------------------------------------------------
   3. COLLECTIONS
   kind: "word"  = image ke beech me collection ka naam
   kind: "index" = image ke beech me neeche wali list
--------------------------------------------------------------------------- */
export type Collection = {
  slug: string;
  name: string;
  kicker: string;
  blurb: string;
  image: string;
  kind: "word" | "index";
  indexList: string[];
};

export const collections: Collection[] = [
  {
    slug: "streetwear",
    name: "Streetwear",
    kicker: "Off-duty",
    blurb:
      "Volume, weight and hardware. Technical outerwear and heavyweight jersey cut for the way the modern man actually moves through a city.",
    image: "images/tile-streetwear.jpg",
    kind: "word",
    indexList: ["New In", "Outerwear", "Knitwear", "Trousers", "Footwear"],
  },
  {
    slug: "tailoring",
    name: "Tailoring",
    kicker: "On the record",
    blurb:
      "Soft-shouldered jackets and pleated trousers in worsted wool and dry twill — professional apparel that keeps its line from breakfast to last call.",
    image: "images/tile-tailoring.jpg",
    kind: "index",
    indexList: ["New In", "Outerwear", "Knitwear", "Trousers", "Footwear"],
  },
];

/* ---------------------------------------------------------------------------
   4. PRODUCTS
   collection: "streetwear" ya "tailoring"  (upar wale slug se match karo)
   featured: true  = Featured Items section me dikhega
   compareAt: purana price (optional — hataao to koi strikethrough nahi)
--------------------------------------------------------------------------- */
export type ProductColor = { name: string; hex: string };

export type Product = {
  slug: string; // page ka address banega: /product/slug
  name: string;
  category: string;
  collection: string;
  price: number; // sirf number, e.g. 980
  compareAt?: number;
  image: string; // main image
  gallery: string[]; // product page par extra images
  colors: ProductColor[];
  sizes: string[];
  description: string;
  fabric: string;
  origin: string;
  featured: boolean;
};

export const products: Product[] = [
  {
    slug: "vantage-leather-blouson",
    name: "Vantage Leather Blouson",
    category: "Outerwear",
    collection: "streetwear",
    price: 980,
    image: "images/p-leather-blouson.jpg",
    gallery: ["images/p-leather-blouson.jpg", "images/hero-main.jpg", "images/hero-detail.jpg"],
    colors: [
      { name: "Espresso", hex: "#2A1B14" },
      { name: "Oxblood", hex: "#7E2B1E" },
    ],
    sizes: ["46", "48", "50", "52", "54"],
    description:
      "An oversized blouson cut from full-grain vegetable-tanned lambskin, dropped through the shoulder and blousoned at the hem. Two-way heavy gauge zip, quilted lining through the body, and a collar that stands on its own.",
    fabric: "100% vegetable-tanned lambskin, cupro lining",
    origin: "Made in Ubrique, Spain",
    featured: true,
  },
  {
    slug: "cinder-houndstooth-overcoat",
    name: "Cinder Houndstooth Overcoat",
    category: "Outerwear",
    collection: "tailoring",
    price: 720,
    compareAt: 860,
    image: "images/p-overcoat.jpg",
    gallery: ["images/p-overcoat.jpg", "images/tile-tailoring.jpg"],
    colors: [
      { name: "Charcoal Check", hex: "#3B3A38" },
      { name: "Stone", hex: "#8C8177" },
    ],
    sizes: ["46", "48", "50", "52", "54"],
    description:
      "A double-breasted overcoat in a 780g houndstooth woven in the Scottish Borders. Belted waist, raglan-adjacent sleeve head and a half-canvas chest so it falls clean over a blazer without bulk.",
    fabric: "90% lambswool, 10% cashmere — 780g",
    origin: "Woven in Hawick, made in Italy",
    featured: true,
  },
  {
    slug: "meridian-double-breasted-blazer",
    name: "Meridian Double-Breasted Blazer",
    category: "Tailoring",
    collection: "tailoring",
    price: 540,
    image: "images/p-blazer.jpg",
    gallery: ["images/p-blazer.jpg", "images/tile-tailoring.jpg", "images/hero-detail.jpg"],
    colors: [
      { name: "Slate Navy", hex: "#2C3340" },
      { name: "Espresso", hex: "#2A1B14" },
    ],
    sizes: ["46", "48", "50", "52", "54"],
    description:
      "Six-by-two peak lapel with an unpadded, soft shoulder and a suppressed waist. Cut in a dry 280g worsted that resists creasing through a long day of travel and rooms that are too cold.",
    fabric: "100% worsted wool, 280g — horn buttons",
    origin: "Made in Naples, Italy",
    featured: true,
  },
  {
    slug: "halo-heavyweight-ribbed-knit",
    name: "Halo Heavyweight Ribbed Knit",
    category: "Knitwear",
    collection: "streetwear",
    price: 280,
    image: "images/p-knit.jpg",
    gallery: ["images/p-knit.jpg", "images/tile-streetwear.jpg"],
    colors: [
      { name: "Oatmeal", hex: "#D8CDBB" },
      { name: "Oxblood", hex: "#7E2B1E" },
      { name: "Ink", hex: "#17110E" },
    ],
    sizes: ["S", "M", "L", "XL"],
    description:
      "A 7-gauge crewneck knitted from undyed Geelong lambswool with a chunky vertical rib and a ribbed saddle shoulder. Heavy enough to wear as outerwear in October.",
    fabric: "100% Geelong lambswool — 7 gauge",
    origin: "Knitted in Donegal, Ireland",
    featured: true,
  },
  {
    slug: "grid-pleated-wide-trouser",
    name: "Grid Pleated Wide Trouser",
    category: "Trousers",
    collection: "tailoring",
    price: 320,
    image: "images/p-trouser.jpg",
    gallery: ["images/p-trouser.jpg", "images/tile-tailoring.jpg"],
    colors: [
      { name: "Stone Grey", hex: "#8C8177" },
      { name: "Ink", hex: "#17110E" },
    ],
    sizes: ["30", "32", "34", "36", "38"],
    description:
      "High-waisted, single reverse pleat, wide through the leg with a hard centre crease and a 5cm turn-up. The drape is deliberate — cut long so it breaks once, cleanly, over the shoe.",
    fabric: "100% wool twill, 260g",
    origin: "Made in Biella, Italy",
    featured: true,
  },
  {
    slug: "foundry-waxed-utility-bomber",
    name: "Foundry Waxed Utility Bomber",
    category: "Streetwear",
    collection: "streetwear",
    price: 610,
    image: "images/p-bomber.jpg",
    gallery: ["images/p-bomber.jpg", "images/tile-streetwear.jpg", "images/hero-main.jpg"],
    colors: [
      { name: "Oxblood", hex: "#7E2B1E" },
      { name: "Field Olive", hex: "#4E4A33" },
    ],
    sizes: ["S", "M", "L", "XL"],
    description:
      "Boxy waxed-cotton bomber with oversized bellows pockets, a ribbed collar and a storm cuff. Dry-waxed so it marks and patinas rather than shines — every one ends up a record of where you took it.",
    fabric: "100% dry-waxed cotton canvas, 10oz",
    origin: "Made in Manchester, England",
    featured: true,
  },
];

/* ---------------------------------------------------------------------------
   5. FEATURED ITEMS  (section ke headings)
--------------------------------------------------------------------------- */
export const featuredItems = {
  title: "Featured",
  subtitle: "Six pieces cut for movement, from natural textures — AW26",
  brandNote: "Designed for the man in motion, made to last",
  moreLabel: "See All Collection",
};

/* ---------------------------------------------------------------------------
   6. COLLECTION BAND
--------------------------------------------------------------------------- */
export const collectionBand = {
  kicker: "AW26 — The Collection",
  title: "Collection",
  buttonLabel: "View",
  buttonHref: "/shop",
  note: "Two registers — street and boardroom — cut from the same block.",
};

/* ---------------------------------------------------------------------------
   7. EDITORIAL / JOURNAL
--------------------------------------------------------------------------- */
export const editorial = {
  kicker: "Journal — Issue 04",
  title: ["Cut for the", "City"],
  italicWords: ["for the"],
  images: ["images/p-knit.jpg", "images/hero-detail.jpg"],
  paragraphs: [
    "TRENDYFLY is built on one idea: the modern man does not change clothes between the studio, the flight and the dinner. So we cut from the same block — a soft shoulder, a suppressed waist, a leg that moves — and change only the cloth.",
    "Everything is made in Europe from natural textures: vegetable-tanned lambskin from Ubrique, 780g houndstooth from the Scottish Borders, dry-waxed Manchester canvas and undyed Donegal lambswool. Nothing decorative. Nothing that will not outlive the season it was cut for.",
  ],
  linkLabel: "Read the Journal",
  linkHref: "/shop",
};

/* ---------------------------------------------------------------------------
   8. FOOTER
--------------------------------------------------------------------------- */
export const footer = {
  columns: [
    { title: "About Us", links: ["Our Story", "Our Spirit", "Our Members", "Careers"] },
    {
      title: "Customer Service",
      links: ["Contact Us", "Delivery Options", "Payment Methods", "Returns & Exchanges"],
    },
  ],
  contact: {
    title: "Call Us",
    tel: "+44 20 7946 0311",
    time: "AM 09:00 — PM 18:00",
    mail: "clientcare@trendyfly.com",
  },
  signature: "Designed for the man in motion — made to last.",
  legalLeft: "Privacy Policy · Terms & Conditions",
};

/* ---------------------------------------------------------------------------
   HELPERS — neeche kuch mat badalna (pages isi ko use karte hain)
--------------------------------------------------------------------------- */
export function featuredProducts(): Product[] {
  return products.filter((p) => p.featured);
}

export function productsByCollection(slug?: string): Product[] {
  if (!slug || slug === "all") return products;
  return products.filter((p) => p.collection === slug);
}

export function getProduct(slug: string): Product | undefined {
  return products.find((p) => p.slug === slug);
}

export function getCollection(slug: string): Collection | undefined {
  return collections.find((c) => c.slug === slug);
}

export function relatedProducts(slug: string, limit = 3): Product[] {
  return products.filter((p) => p.slug !== slug).slice(0, limit);
}

export function searchProducts(term: string): Product[] {
  const q = term.trim().toLowerCase();
  if (!q) return products;
  return products.filter((p) =>
    [p.name, p.category, p.description, p.fabric, p.origin, p.collection]
      .join(" ")
      .toLowerCase()
      .includes(q),
  );
}

export function formatPrice(price: number): string {
  return `$${price.toLocaleString("en-US")}`;
}
