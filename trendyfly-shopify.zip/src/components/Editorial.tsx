import Link from "next/link";
import { editorial } from "@/data/site";

export function Editorial() {
  return (
    <section id="editorial" className="bg-paper px-4 py-20 md:px-10 md:py-28">
      <div className="mx-auto grid max-w-[1600px] gap-10 md:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)] md:items-center md:gap-16">
        <div className="grid grid-cols-2 gap-3">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={editorial.images[0]}
            alt="Geelong lambswool ribbed knit and oxblood scarf"
            loading="lazy"
            className="h-[42vh] w-full object-cover md:h-[54vh]"
          />
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={editorial.images[1]}
            alt="Leather trouser drape detail"
            loading="lazy"
            className="mt-10 h-[42vh] w-full object-cover object-[40%_40%] md:h-[54vh]"
          />
        </div>

        <div>
          <span className="label text-stone">{editorial.kicker}</span>
          <h2 className="display mt-5 text-[clamp(2.4rem,4.6vw,4rem)] leading-[1.02]">
            {editorial.title.map((line, i) => {
              const words = line.split(" ");
              return (
                <span key={i}>
                  {words.map((word, j) => (
                    <span key={j}>
                      {j > 0 ? " " : ""}
                      {editorial.italicWords.includes(word) ? (
                        <span className="italic">{word}</span>
                      ) : (
                        word
                      )}
                    </span>
                  ))}
                  {i < editorial.title.length - 1 ? <br /> : null}
                </span>
              );
            })}
          </h2>
          <div className="rule-draw mt-6 h-px w-16 bg-oxblood" />
          <div className="mt-7 max-w-[52ch] space-y-5 text-[15px] leading-[1.85] text-stone">
            {editorial.paragraphs.map((p, i) => (
              <p key={i}>{p}</p>
            ))}
          </div>
          <Link
            href={editorial.linkHref}
            className="focusable link-underline label-lg mt-8 inline-block border-b border-ink pb-1"
          >
            {editorial.linkLabel} ↗
          </Link>
        </div>
      </div>
    </section>
  );
}
