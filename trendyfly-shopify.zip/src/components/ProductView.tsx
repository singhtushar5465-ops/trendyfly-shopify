"use client";

import { useState } from "react";
import { useCart, formatPrice } from "@/components/CartProvider";
import { WishlistButton } from "@/components/WishlistButton";
import type { Product } from "@/data/site";

export function ProductView({ product }: { product: Product }) {
  const { add } = useCart();
  const gallery = product.gallery?.length ? product.gallery : [product.image];
  const [active, setActive] = useState(0);
  const [size, setSize] = useState<string | null>(product.sizes?.[1] ?? product.sizes?.[0] ?? null);
  const [color, setColor] = useState(product.colors?.[0]?.name ?? null);

  return (
    <div className="grid gap-10 md:grid-cols-[minmax(0,1.1fr)_minmax(0,1fr)] md:gap-16">
      {/* gallery */}
      <div className="flex gap-4">
        <div className="flex w-16 shrink-0 flex-col gap-3 md:w-20">
          {gallery.map((src, i) => (
            <button
              key={src + i}
              type="button"
              onClick={() => setActive(i)}
              aria-label={`View image ${i + 1}`}
              className={`focusable relative overflow-hidden transition-opacity ${
                active === i ? "opacity-100 ring-1 ring-ink" : "opacity-55 hover:opacity-90"
              }`}
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={src} alt="" className="aspect-[3/4] w-full object-cover" />
            </button>
          ))}
        </div>
        <div className="grain relative flex-1 overflow-hidden bg-paper-2 ring-1 ring-ink/10">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={gallery[active]}
            alt={product.name}
            className="aspect-[3/4] w-full object-cover"
          />
        </div>
      </div>

      {/* details */}
      <div className="md:pt-4">
        <span className="label text-stone">
          {product.category} — AW26
        </span>
        <h1 className="display mt-4 text-[clamp(2.2rem,4vw,3.4rem)] leading-[1.02]">
          {product.name}
        </h1>
        <div className="mt-4 flex items-baseline gap-4">
          <span className="num text-xl font-semibold text-oxblood">{formatPrice(product.price)}</span>
          {product.compareAt ? (
            <span className="num text-sm text-stone line-through">{formatPrice(product.compareAt)}</span>
          ) : null}
        </div>

        <p className="mt-7 max-w-[52ch] text-[15px] leading-[1.85] text-stone">{product.description}</p>

        {/* colours */}
        {product.colors?.length ? (
          <div className="mt-8">
            <p className="label mb-3 text-stone">
              Colour — <span className="text-ink">{color}</span>
            </p>
            <div className="flex gap-2">
              {product.colors.map((c) => (
                <button
                  key={c.name}
                  type="button"
                  onClick={() => setColor(c.name)}
                  aria-label={c.name}
                  className={`focusable h-7 w-7 transition-transform ${
                    color === c.name ? "ring-1 ring-ink ring-offset-2 ring-offset-paper" : ""
                  }`}
                  style={{ background: c.hex }}
                />
              ))}
            </div>
          </div>
        ) : null}

        {/* sizes */}
        <div className="mt-8">
          <div className="mb-3 flex items-baseline justify-between">
            <p className="label text-stone">Size</p>
            <span className="label link-underline cursor-pointer text-ink">Size guide</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {product.sizes?.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setSize(s)}
                className={`label focusable min-w-[3.4rem] border px-4 py-3 transition-colors ${
                  size === s
                    ? "border-ink bg-ink text-paper-2"
                    : "hairline border text-ink hover:border-ink"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        <button
          type="button"
          disabled={!size}
          onClick={() =>
            size &&
            add({
              slug: product.slug,
              name: product.name,
              size,
              price: product.price,
              image: product.image,
            })
          }
          className="label-lg focusable mt-8 flex w-full items-center justify-center gap-3 bg-ink py-5 text-paper-2 transition-colors hover:bg-oxblood disabled:cursor-not-allowed disabled:opacity-40"
        >
          {size ? "Add to bag ↗" : "Select a size"}
        </button>

        <WishlistButton
          variant="wide"
          item={{
            slug: product.slug,
            name: product.name,
            category: product.category,
            price: product.price,
            image: product.image,
            sizes: product.sizes ?? [],
            colors: product.colors ?? null,
          }}
        />

        <dl className="mt-10 divide-y hairline border-y hairline">
          <div className="flex justify-between gap-6 py-4">
            <dt className="label text-stone">Fabric</dt>
            <dd className="text-right text-sm">{product.fabric}</dd>
          </div>
          <div className="flex justify-between gap-6 py-4">
            <dt className="label text-stone">Origin</dt>
            <dd className="text-right text-sm">{product.origin}</dd>
          </div>
          <div className="flex justify-between gap-6 py-4">
            <dt className="label text-stone">Delivery</dt>
            <dd className="text-right text-sm">
              Complimentary express shipping, 2–4 working days. Free returns within 30 days.
            </dd>
          </div>
        </dl>
      </div>
    </div>
  );
}
