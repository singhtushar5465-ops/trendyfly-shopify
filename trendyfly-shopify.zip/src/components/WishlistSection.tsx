"use client";

import Link from "next/link";
import { SampleCard, type SampleProduct } from "@/components/SampleCard";
import { HeartIcon } from "@/components/WishlistButton";
import { useWishlist } from "@/components/WishlistProvider";

export function WishlistSection({ fallback }: { fallback: SampleProduct[] }) {
  const { items, count } = useWishlist();
  const saved = items.slice(0, 4) as SampleProduct[];
  const shown = count > 0 ? saved : fallback.slice(0, 4);

  return (
    <section id="wishlist" className="bg-paper-2 px-4 py-20 md:px-10 md:py-24">
      <div className="mx-auto max-w-[1600px]">
        <div className="grid gap-6 md:grid-cols-[minmax(0,1fr)_minmax(0,1fr)] md:items-end">
          <div>
            <span className="label text-stone">
              {count > 0 ? `Wishlist — ${count} saved` : "Wishlist — Saved by You"}
            </span>
            <h2 className="display mt-4 text-[clamp(2.4rem,6vw,4.6rem)] leading-[1.02]">
              {count > 0 ? (
                <>
                  Kept <span className="italic">for later</span>
                </>
              ) : (
                <>
                  Most <span className="italic">wished</span>
                </>
              )}
            </h2>
          </div>
          <div className="flex items-end justify-between gap-6 md:justify-self-end md:text-right">
            <p className="label max-w-[34ch] leading-[1.9] text-stone">
              {count > 0
                ? "Pinned pieces wait here — move them to the bag when the season turns."
                : "Tap the heart on any piece to pin it here. The four most wished-for pieces of AW26, until you add your own."}
            </p>
            <Link
              href="/wishlist"
              className="focusable label-lg link-underline shrink-0 border-b border-ink pb-1"
            >
              {count > 0 ? "View wishlist" : "Your wishlist"} ↗
            </Link>
          </div>
        </div>

        <div className="rule-draw mt-6 h-px w-full bg-ink/20" />

        {count === 0 ? (
          <p className="mt-6 flex items-center gap-2 text-sm text-stone">
            <HeartIcon filled={false} className="h-4 w-4" /> Nothing pinned yet — showing the most
            wished-for pieces instead.
          </p>
        ) : null}

        <div className="mt-10 grid grid-cols-4 gap-x-5 gap-y-14 md:gap-x-8 lg:grid-cols-12">
          {shown.map((p, i) => (
            <SampleCard key={p.slug} product={p} index={i} staggered={false} />
          ))}
        </div>
      </div>
    </section>
  );
}
