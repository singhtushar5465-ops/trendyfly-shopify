"use client";

import { useState } from "react";
import Link from "next/link";
import { HeartIcon } from "@/components/WishlistButton";
import { formatPrice } from "@/lib/format";
import { useCart } from "@/components/CartProvider";
import { useWishlist, type WishlistItem } from "@/components/WishlistProvider";

export function WishlistView() {
  const { items, remove } = useWishlist();
  const { add, setOpen } = useCart();
  const [sizes, setSizes] = useState<Record<string, string>>({});

  if (items.length === 0) {
    return (
      <div className="py-24 text-center">
        <HeartIcon filled={false} className="mx-auto h-8 w-8 text-stone" />
        <p className="display mt-6 text-[clamp(2rem,4vw,3rem)] italic">Nothing pinned yet.</p>
        <p className="mt-4 text-sm text-stone">
          Tap the heart on any piece to pin it here — it stays until you say otherwise.
        </p>
        <Link href="/shop" className="focusable label-lg mt-8 inline-block border-b border-ink pb-1">
          Browse the collection ↗
        </Link>
      </div>
    );
  }

  return (
    <ul className="divide-y hairline border-t hairline">
      {items.map((item) => (
        <WishlistRow
          key={item.slug}
          item={item}
          size={sizes[item.slug] ?? item.sizes[0] ?? ""}
          onSize={(s) => setSizes((prev) => ({ ...prev, [item.slug]: s }))}
          onMove={() => {
            const size = sizes[item.slug] ?? item.sizes[0] ?? "M";
            add({
              slug: item.slug,
              name: item.name,
              size,
              price: item.price,
              image: item.image,
            });
            setOpen(true);
          }}
          onRemove={() => remove(item.slug)}
        />
      ))}
    </ul>
  );
}

function WishlistRow({
  item,
  size,
  onSize,
  onMove,
  onRemove,
}: {
  item: WishlistItem;
  size: string;
  onSize: (s: string) => void;
  onMove: () => void;
  onRemove: () => void;
}) {
  return (
    <li className="flex flex-wrap items-center gap-6 py-6">
      <Link href={`/product/${item.slug}`} className="focusable shrink-0">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={item.image}
          alt={item.name}
          className="h-32 w-24 object-cover transition-transform duration-500 hover:-translate-y-1"
        />
      </Link>

      <div className="min-w-[10rem] flex-1">
        <span className="label text-stone">{item.category}</span>
        <Link href={`/product/${item.slug}`} className="focusable link-underline mt-1 block text-[15px] font-semibold">
          {item.name}
        </Link>
        <p className="num mt-2 text-[15px] text-oxblood">{formatPrice(item.price)}</p>
        {item.colors?.length ? (
          <div className="mt-3 flex gap-1.5">
            {item.colors.slice(0, 3).map((c) => (
              <span
                key={c.name}
                title={c.name}
                className="block h-2.5 w-2.5 shadow-[0_0_0_1px_rgba(23,17,14,0.18)]"
                style={{ background: c.hex }}
              />
            ))}
          </div>
        ) : null}
      </div>

      <label className="flex items-center gap-3">
        <span className="label text-stone">Size</span>
        <select
          value={size}
          onChange={(e) => onSize(e.target.value)}
          aria-label={`Size for ${item.name}`}
          className="label focusable hairline border bg-transparent px-4 py-3"
        >
          {item.sizes.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </label>

      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={onMove}
          className="label focusable bg-ink px-6 py-3.5 text-paper-2 transition-colors hover:bg-oxblood"
        >
          Move to bag
        </button>
        <button
          type="button"
          onClick={onRemove}
          className="label focusable hairline border px-5 py-3.5 text-stone transition-colors hover:border-oxblood hover:text-oxblood"
        >
          Remove
        </button>
      </div>
    </li>
  );
}
