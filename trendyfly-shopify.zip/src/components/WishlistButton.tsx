"use client";

import { useWishlist, type WishlistItem } from "@/components/WishlistProvider";

export function HeartIcon({ filled, className = "h-4 w-4" }: { filled: boolean; className?: string }) {
  const d =
    "M12 20.8 C12 20.8 3.2 14.6 3.2 8.9 C3.2 5.9 5.5 3.8 8.2 3.8 C10 3.8 11.3 4.8 12 6.1 C12.7 4.8 14 3.8 15.8 3.8 C18.5 3.8 20.8 5.9 20.8 8.9 C20.8 14.6 12 20.8 12 20.8 Z";
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
      <path
        d={d}
        fill={filled ? "currentColor" : "none"}
        stroke="currentColor"
        strokeWidth={filled ? 0 : 1.6}
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function WishlistButton({
  item,
  variant = "chip",
}: {
  item: WishlistItem;
  variant?: "chip" | "wide";
}) {
  const { has, toggle } = useWishlist();
  const saved = has(item.slug);

  if (variant === "chip") {
    return (
      <button
        type="button"
        onClick={() => toggle(item)}
        aria-pressed={saved}
        aria-label={saved ? `Remove ${item.name} from wishlist` : `Save ${item.name} to wishlist`}
        title={saved ? "Saved" : "Save to wishlist"}
        className={`focusable flex h-8 w-8 items-center justify-center bg-paper-2/90 ring-1 ring-ink/10 transition-colors ${
          saved ? "text-oxblood" : "text-ink hover:bg-ink hover:text-paper-2"
        }`}
      >
        <HeartIcon filled={saved} className="h-[15px] w-[15px]" />
      </button>
    );
  }

  return (
    <button
      type="button"
      onClick={() => toggle(item)}
      aria-pressed={saved}
      className={`label-lg focusable mt-3 flex w-full items-center justify-center gap-3 border py-4 transition-colors ${
        saved
          ? "border-oxblood bg-oxblood/8 text-oxblood hover:bg-oxblood hover:text-paper-2"
          : "hairline border hover:border-ink"
      }`}
    >
      <HeartIcon filled={saved} className="h-[15px] w-[15px]" />
      {saved ? "Saved to wishlist" : "Save to wishlist"}
    </button>
  );
}
