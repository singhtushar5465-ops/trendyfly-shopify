import Link from "next/link";
import { hero } from "@/data/site";

export function Hero() {
  return (
    <section className="px-2 pt-2 md:px-3 md:pt-3">
      <div className="grid gap-2 md:grid-cols-[minmax(0,2fr)_minmax(0,1fr)] md:gap-3">
        {/* main panel */}
        <div className="relative overflow-hidden bg-leather">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={hero.mainImage}
            alt="TRENDYFLY AW26"
            className="h-[64vh] w-full object-cover object-[30%_35%] md:h-[78vh]"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ink/70 via-ink/10 to-transparent" />

          <div className="absolute top-5 left-5 flex flex-col gap-1 md:top-7 md:left-7">
            <span className="label text-paper-2/80">{hero.season}</span>
            <span className="label text-paper-2/50">{hero.origin}</span>
          </div>

          <div className="absolute right-5 bottom-6 max-w-[19ch] md:right-8 md:bottom-10">
            <h1 className="slab text-paper-2 text-[clamp(2.6rem,6vw,5.4rem)]">
              {hero.title.map((line, i) => {
                const words = line.split(" ");
                return (
                  <span key={i}>
                    {words.map((word, j) => (
                      <span key={j}>
                        {j > 0 ? " " : ""}
                        {hero.italicWords.includes(word) ? (
                          <em style={{ fontFamily: "var(--font-display)", fontWeight: 400 }}>{word}</em>
                        ) : (
                          word
                        )}
                      </span>
                    ))}
                    {i < hero.title.length - 1 ? <br /> : null}
                  </span>
                );
              })}
            </h1>
            <Link
              href={hero.ctaHref}
              className="focusable group mt-6 inline-flex items-center gap-4 bg-paper-2 py-2.5 pr-2.5 pl-5 text-ink transition-colors hover:bg-oxblood hover:text-paper-2"
            >
              <span className="label-lg">{hero.ctaLabel}</span>
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-ink text-paper-2 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5">
                ↗
              </span>
            </Link>
          </div>
        </div>

        {/* narrow detail panel */}
        <div className="relative hidden overflow-hidden bg-ink md:block">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={hero.sideImage}
            alt="TRENDYFLY AW26 detail"
            className="h-[78vh] w-full object-cover object-center"
          />
          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink/80 to-transparent p-7">
            <p className="display text-paper-2 text-xl leading-tight italic">{hero.sideNote}</p>
            <p className="label mt-3 text-paper-2/60">Fabrics of AW26</p>
          </div>
        </div>
      </div>
    </section>
  );
}
