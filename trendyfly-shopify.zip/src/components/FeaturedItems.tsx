import Link from "next/link";
import { SampleCard } from "@/components/SampleCard";
import { Logo } from "@/components/Logo";
import { featuredItems, type Product } from "@/data/site";

export function FeaturedItems({ products }: { products: Product[] }) {
  return (
    <section id="featured" className="mt-8 bg-paper px-4 pt-14 pb-20 md:px-10 md:pt-20">
      <div className="mx-auto max-w-[1600px]">
        <div className="grid gap-6 md:grid-cols-2 md:items-end">
          <div>
            <h2 className="slab text-[clamp(3.2rem,10vw,8.5rem)]">{featuredItems.title}</h2>
            <p className="label mt-4 max-w-[34ch] leading-[1.9] text-stone">
              {featuredItems.subtitle}
            </p>
          </div>
          <div className="md:justify-self-end md:text-right">
            <Logo markClass="h-6 w-auto" wordClass="text-[26px]" />
            <p className="label mt-3 max-w-[30ch] leading-[1.9] text-stone md:ml-auto">
              {featuredItems.brandNote}
            </p>
          </div>
        </div>

        <div className="rule-draw mt-6 h-px w-full bg-ink/20" />

        <div className="mt-10 grid grid-cols-4 gap-x-5 gap-y-14 md:gap-x-6 lg:grid-cols-12 lg:gap-x-6">
          {products.map((p, i) => (
            <SampleCard key={p.slug} product={p} index={i} />
          ))}
        </div>

        <div className="mt-10 flex justify-end">
          <Link
            href="/shop"
            className="focusable link-underline label-lg border-b border-ink pb-1"
          >
            See All Collection ↗
          </Link>
        </div>
      </div>
    </section>
  );
}
