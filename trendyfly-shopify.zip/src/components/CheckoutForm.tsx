"use client";

import Link from "next/link";
import { useState, type FormEvent } from "react";
import { formatPrice, useCart } from "@/components/CartProvider";

export function CheckoutForm() {
  const { lines, total, clear, count } = useCart();
  const [state, setState] = useState<"idle" | "sending" | "done" | "error">("idle");
  const [ref, setRef] = useState<string | null>(null);
  const [receiptTotal, setReceiptTotal] = useState(0);

  function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (lines.length === 0) return;
    setState("sending");

    // Frontend-only storefront: the order is recorded locally (no database).
    const form = new FormData(e.currentTarget);
    const email = String(form.get("email") ?? "").trim();
    const name = String(form.get("name") ?? "").trim();
    if (!email || !name) {
      setState("error");
      return;
    }

    const placedTotal = total;
    const orderRef = `TF-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;

    try {
      const key = "trendyfly.orders.v1";
      const existing = JSON.parse(window.localStorage.getItem(key) || "[]");
      existing.unshift({ ref: orderRef, email, name, total: placedTotal, items: lines });
      window.localStorage.setItem(key, JSON.stringify(existing.slice(0, 25)));
    } catch {
      /* storage may be unavailable — the confirmation still shows */
    }

    setRef(orderRef);
    setReceiptTotal(placedTotal);
    clear();
    setState("done");
  }

  if (state === "done") {
    return (
      <div className="mx-auto max-w-[46rem] py-24 text-center">
        <span className="label text-stone">Order confirmed</span>
        <h1 className="display mt-5 text-[clamp(2.4rem,5vw,4rem)] leading-[1.02]">
          Thank you. <span className="italic">It&apos;s yours.</span>
        </h1>
        <div className="rule-draw mx-auto mt-6 h-px w-16 bg-oxblood" />
        <p className="mt-8 text-[15px] leading-relaxed text-stone">
          Reference <span className="num font-semibold text-ink">{ref}</span> — a confirmation is on
          its way. Total charged:{" "}
          <span className="num font-semibold text-ink">{formatPrice(receiptTotal)}</span>.
        </p>
        <Link href="/shop" className="focusable label-lg mt-10 inline-block border-b border-ink pb-1">
          Continue shopping ↗
        </Link>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="grid gap-12 md:grid-cols-[minmax(0,1fr)_24rem] md:gap-16">
      <div>
        <h1 className="display text-[clamp(2.4rem,5vw,3.8rem)] leading-[1.02]">Checkout</h1>
        <div className="rule-draw mt-6 h-px w-full bg-ink/20" />

        <div className="mt-8 space-y-6">
          <Field label="Email" name="email" type="email" placeholder="you@studio.com" required />
          <Field label="Full name" name="name" type="text" placeholder="Alexander Reed" required />
          <div className="grid gap-6 sm:grid-cols-2">
            <Field label="City" name="city" type="text" placeholder="London" required />
            <Field label="Postcode" name="postcode" type="text" placeholder="EC2A 3AY" required />
          </div>
          <Field label="Address" name="address" type="text" placeholder="14 Redchurch Street" required />
        </div>

        <p className="mt-6 text-[11px] leading-relaxed text-stone">
          This is a frontend demonstration storefront — no card is taken and no goods are shipped. Your
          order reference is generated in the browser and saved to this device only.
        </p>

        <button
          type="submit"
          disabled={lines.length === 0 || state === "sending"}
          className="label-lg focusable mt-8 w-full bg-ink py-5 text-paper-2 transition-colors hover:bg-oxblood disabled:cursor-not-allowed disabled:opacity-40"
        >
          {state === "sending" ? "Placing order…" : `Place order — ${formatPrice(total)}`}
        </button>
        {state === "error" ? (
          <p className="label mt-4 text-oxblood">Please add your email and name.</p>
        ) : null}
      </div>

      <aside className="h-fit bg-paper-2 p-7 ring-1 ring-ink/10">
        <h2 className="label-lg">
          Bag <span className="num text-stone">({count})</span>
        </h2>
        <ul className="mt-6 divide-y hairline">
          {lines.length === 0 ? (
            <li className="py-6 text-sm text-stone">Your bag is empty.</li>
          ) : (
            lines.map((l) => (
              <li key={`${l.slug}-${l.size}`} className="flex gap-4 py-4">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={l.image} alt="" className="h-20 w-14 shrink-0 object-cover" />
                <div className="flex-1">
                  <p className="text-[13px] leading-tight font-semibold">{l.name}</p>
                  <p className="label mt-1 text-stone">
                    Size {l.size} · Qty {l.qty}
                  </p>
                </div>
                <span className="num text-[13px]">{formatPrice(l.price * l.qty)}</span>
              </li>
            ))
          )}
        </ul>
        <div className="mt-6 flex items-baseline justify-between border-t hairline pt-5">
          <span className="label-lg">Total</span>
          <span className="num text-lg font-semibold">{formatPrice(total)}</span>
        </div>
      </aside>
    </form>
  );
}

function Field({
  label,
  name,
  type,
  placeholder,
  required,
}: {
  label: string;
  name: string;
  type: string;
  placeholder: string;
  required?: boolean;
}) {
  return (
    <label className="block">
      <span className="label text-stone">{label}</span>
      <input
        name={name}
        type={type}
        required={required}
        placeholder={placeholder}
        className="focusable mt-2 w-full border-b hairline border-b bg-transparent py-3 text-[15px] placeholder:text-stone/50 focus:border-ink"
      />
    </label>
  );
}
