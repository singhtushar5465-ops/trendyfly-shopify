import Link from "next/link";
import { LogoMark } from "@/components/Logo";
import { footer } from "@/data/site";

export function Footer() {
  return (
    <footer className="border-t hairline bg-paper">
      <div className="mx-auto max-w-[1600px] px-5 py-16 md:px-8">
        <div className="grid gap-12 md:grid-cols-[1fr_1fr_1fr_minmax(0,1.4fr)]">
          {footer.columns.map((col) => (
            <div key={col.title}>
              <h3 className="label-lg mb-5">{col.title}</h3>
              <ul className="space-y-3">
                {col.links.map((l) => (
                  <li key={l}>
                    <Link href="/shop" className="focusable link-underline text-sm text-stone hover:text-ink">
                      {l}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          <div>
            <h3 className="label-lg mb-5">{footer.contact.title}</h3>
            <dl className="space-y-3 text-sm text-stone">
              <div className="flex gap-3">
                <dt className="label pt-1 text-ink">Tel</dt>
                <dd className="num">{footer.contact.tel}</dd>
              </div>
              <div className="flex gap-3">
                <dt className="label pt-1 text-ink">Time</dt>
                <dd className="num">{footer.contact.time}</dd>
              </div>
              <div className="flex gap-3">
                <dt className="label pt-1 text-ink">Mail</dt>
                <dd>{footer.contact.mail}</dd>
              </div>
            </dl>
          </div>

          <div className="flex flex-col justify-between gap-6">
            <p className="display max-w-[30ch] text-2xl leading-[1.15] italic">
              {footer.signature}
            </p>
            <div className="flex items-end justify-between">
              <LogoMark className="h-8 w-auto text-ink" />
              <span className="label text-stone">AW26 — London</span>
            </div>
          </div>
        </div>
      </div>

      <div className="border-t hairline">
        <div className="mx-auto flex max-w-[1600px] flex-col items-center justify-between gap-3 px-5 py-6 text-center md:flex-row md:px-8 md:text-left">
          <p className="label text-stone">{footer.legalLeft}</p>
          <p className="label text-stone">© 2026 TRENDYFLY — All rights reserved</p>
        </div>
      </div>
    </footer>
  );
}
