"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState, type FormEvent } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { formatPrice } from "@/lib/format";

type Result = {
  slug: string;
  name: string;
  category: string;
  price: number;
  image: string;
};

const quickLinks = [
  { label: "Streetwear", href: "/shop?c=streetwear" },
  { label: "Tailoring", href: "/shop?c=tailoring" },
  { label: "New In", href: "/shop" },
  { label: "All Pieces", href: "/shop" },
];

const suggestions = ["Leather", "Blazer", "Wool", "Trouser", "Knit", "Bomber"];

export function SearchOverlay({ open, onClose }: { open: boolean; onClose: () => void }) {
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Result[]>([]);
  const [state, setState] = useState<"idle" | "loading" | "ready">("idle");

  useEffect(() => {
    if (!open) return;
    const t = window.setTimeout(() => inputRef.current?.focus(), 60);
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      window.clearTimeout(t);
      window.removeEventListener("keydown", onKey);
    };
  }, [open, onClose]);

  useEffect(() => {
    if (!open) return;
    const term = query.trim();
    if (!term) {
      setResults([]);
      setState("idle");
      return;
    }
    setState("loading");
    const controller = new AbortController();
    const t = window.setTimeout(async () => {
      try {
        const res = await fetch(`/api/products?q=${encodeURIComponent(term)}`, {
          signal: controller.signal,
        });
        const data = (await res.json()) as { products: Result[] };
        setResults(data.products);
        setState("ready");
      } catch {
        setState("ready");
      }
    }, 180);
    return () => {
      controller.abort();
      window.clearTimeout(t);
    };
  }, [query, open]);

  function goToResults() {
    const term = query.trim();
    if (!term) return;
    onClose();
    router.push(`/search?q=${encodeURIComponent(term)}`);
  }

  function submit(e: FormEvent) {
    e.preventDefault();
    goToResults();
  }

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.button
            type="button"
            aria-label="Close search"
            onClick={onClose}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 bg-ink/50"
          />
          <motion.div
            initial={{ y: -24, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -24, opacity: 0 }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
            role="dialog"
            aria-label="Search TRENDYFLY"
            className="fixed inset-x-0 top-0 z-50 max-h-[88vh] overflow-y-auto bg-paper shadow-[0_30px_80px_rgba(23,17,14,0.35)]"
          >
            <div className="mx-auto max-w-[1600px] px-5 py-8 md:px-8 md:py-10">
              <div className="flex items-center justify-between">
                <span className="label text-stone">Search — AW26</span>
                <button
                  type="button"
                  onClick={onClose}
                  className="label focusable text-stone transition-colors hover:text-oxblood"
                >
                  Close
                </button>
              </div>

              <form onSubmit={submit} className="mt-6 border-b hairline pb-4">
                <div className="flex items-center gap-4">
                  <span aria-hidden="true" className="text-2xl text-stone">
                    ⌕
                  </span>
                  <input
                    ref={inputRef}
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Search leather, blazer, wool…"
                    aria-label="Search products"
                    className="display focusable w-full bg-transparent text-[clamp(1.8rem,4vw,3rem)] leading-tight outline-none placeholder:text-stone/45"
                  />
                  <button
                    type="submit"
                    className="label focusable shrink-0 border border-ink px-5 py-3 transition-colors hover:bg-ink hover:text-paper-2"
                  >
                    Search
                  </button>
                </div>
              </form>

              {query.trim() === "" ? (
                <div className="mt-8 grid gap-8 md:grid-cols-2">
                  <div>
                    <p className="label text-stone">Collections</p>
                    <ul className="mt-4 space-y-3">
                      {quickLinks.map((l) => (
                        <li key={l.label}>
                          <Link
                            href={l.href}
                            onClick={onClose}
                            className="display focusable link-underline text-2xl"
                          >
                            {l.label}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <p className="label text-stone">Try</p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      {suggestions.map((s) => (
                        <button
                          key={s}
                          type="button"
                          onClick={() => setQuery(s)}
                          className="label focusable hairline border px-4 py-2.5 transition-colors hover:border-ink hover:text-oxblood"
                        >
                          {s}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="mt-8">
                  <p className="label text-stone">
                    {state === "loading"
                      ? "Searching…"
                      : `${results.length} ${results.length === 1 ? "piece" : "pieces"} found`}
                  </p>

                  {state === "ready" && results.length === 0 ? (
                    <p className="display mt-8 text-2xl italic">
                      Nothing matches “{query}”. Try leather, wool or blazer.
                    </p>
                  ) : (
                    <ul className="mt-5 grid gap-x-8 gap-y-5 md:grid-cols-2">
                      {results.map((p) => (
                        <li key={p.slug}>
                          <Link
                            href={`/product/${p.slug}`}
                            onClick={onClose}
                            className="focusable group flex items-center gap-4 border-b hairline pb-4"
                          >
                            {/* eslint-disable-next-line @next/next/no-img-element */}
                            <img
                              src={p.image}
                              alt=""
                              className="h-20 w-14 shrink-0 object-cover transition-transform duration-500 group-hover:-translate-y-1"
                            />
                            <span className="flex-1">
                              <span className="block text-[13px] font-semibold">{p.name}</span>
                              <span className="label mt-1 block text-stone">{p.category}</span>
                            </span>
                            <span className="num text-[13px] text-oxblood">
                              {formatPrice(p.price)}
                            </span>
                          </Link>
                        </li>
                      ))}
                    </ul>
                  )}

                  {results.length > 0 ? (
                    <button
                      type="button"
                      onClick={goToResults}
                      className="focusable label-lg link-underline mt-8 inline-block border-b border-ink pb-1"
                    >
                      See all results ↗
                    </button>
                  ) : null}
                </div>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
