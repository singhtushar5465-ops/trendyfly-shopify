"use client";

import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { formatPrice, useCart } from "@/components/CartProvider";

export function CartDrawer() {
  const { lines, total, open, setOpen, remove, setQty, count } = useCart();

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.button
            type="button"
            aria-label="Close bag"
            onClick={() => setOpen(false)}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 bg-ink/45 backdrop-blur-[2px]"
          />
          <motion.aside
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", stiffness: 260, damping: 32 }}
            className="fixed top-0 right-0 z-50 flex h-full w-full max-w-[26rem] flex-col bg-paper-2 shadow-[0_0_80px_rgba(23,17,14,0.35)]"
            aria-label="Shopping bag"
          >
            <header className="flex items-center justify-between border-b hairline px-6 py-5">
              <span className="label-lg">
                Bag <span className="num text-stone">({count})</span>
              </span>
              <button
                type="button"
                onClick={() => setOpen(false)}
                className="label focusable text-stone transition-colors hover:text-oxblood"
              >
                Close
              </button>
            </header>

            {lines.length === 0 ? (
              <div className="flex flex-1 flex-col items-center justify-center gap-4 px-8 text-center">
                <p className="display text-3xl italic">Nothing pinned yet.</p>
                <p className="max-w-[22ch] text-sm leading-relaxed text-stone">
                  Your bag is empty. Start with the AW26 featured run.
                </p>
                <button
                  type="button"
                  onClick={() => setOpen(false)}
                  className="label focusable border-b border-oxblood pb-1 text-oxblood"
                >
                  Continue shopping
                </button>
              </div>
            ) : (
              <ul className="flex-1 divide-y hairline overflow-y-auto px-6">
                {lines.map((l) => (
                  <li key={`${l.slug}-${l.size}`} className="flex gap-4 py-5">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={l.image}
                      alt={l.name}
                      className="h-24 w-[4.5rem] shrink-0 object-cover"
                    />
                    <div className="flex flex-1 flex-col justify-between">
                      <div>
                        <p className="text-[13px] leading-tight font-semibold">{l.name}</p>
                        <p className="label mt-1 text-stone">Size {l.size}</p>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center border hairline">
                          <button
                            type="button"
                            aria-label={`Decrease quantity of ${l.name}`}
                            onClick={() => setQty(l.slug, l.size, l.qty - 1)}
                            className="focusable px-2 py-1 text-sm text-stone hover:text-ink"
                          >
                            –
                          </button>
                          <span className="num w-6 text-center text-xs">{l.qty}</span>
                          <button
                            type="button"
                            aria-label={`Increase quantity of ${l.name}`}
                            onClick={() => setQty(l.slug, l.size, l.qty + 1)}
                            className="focusable px-2 py-1 text-sm text-stone hover:text-ink"
                          >
                            +
                          </button>
                        </div>
                        <span className="num text-[13px]">{formatPrice(l.price * l.qty)}</span>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => remove(l.slug, l.size)}
                      aria-label={`Remove ${l.name}`}
                      className="label focusable self-start text-stone hover:text-oxblood"
                    >
                      ✕
                    </button>
                  </li>
                ))}
              </ul>
            )}

            <footer className="border-t hairline px-6 py-5">
              <div className="flex items-baseline justify-between">
                <span className="label-lg">Subtotal</span>
                <span className="num text-lg font-semibold">{formatPrice(total)}</span>
              </div>
              <p className="mt-2 text-[11px] leading-relaxed text-stone">
                Duties and shipping calculated at checkout. Complimentary returns within 30 days.
              </p>
              <Link
                href="/checkout"
                onClick={() => setOpen(false)}
                className={`label-lg focusable mt-4 flex w-full items-center justify-center gap-2 bg-ink py-4 text-paper-2 transition-colors hover:bg-oxblood ${
                  lines.length === 0 ? "pointer-events-none opacity-40" : ""
                }`}
              >
                Checkout ↗
              </Link>
            </footer>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
