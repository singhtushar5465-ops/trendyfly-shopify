"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { WishlistButton } from "@/components/WishlistButton";
import { formatPrice } from "@/lib/format";

export type SampleProduct = {
  slug: string;
  name: string;
  category: string;
  price: number;
  image: string;
  colors?: { name: string; hex: string }[] | null;
};

type Layout = {
  card: string;
  plate: string;
  ratio: string;
  chips: string;
};

const layouts: Layout[] = [
  {
    card: "col-span-2 lg:col-span-4 mt-0",
    plate: "inset-x-[7%] top-[15%] bottom-[6%]",
    ratio: "aspect-[3/4]",
    chips: "top-[46%] -right-1",
  },
  {
    card: "col-span-2 lg:col-span-3 mt-12 lg:mt-16",
    plate: "inset-x-[10%] top-[12%] bottom-[8%]",
    ratio: "aspect-[2/3]",
    chips: "bottom-[16%] -right-1",
  },
  {
    card: "col-span-2 lg:col-span-5 mt-4 lg:mt-8",
    plate: "inset-x-[6%] top-[18%] bottom-[4%]",
    ratio: "aspect-[4/5]",
    chips: "top-[28%] -left-1",
  },
  {
    card: "col-span-2 lg:col-start-2 lg:col-span-3 mt-14 lg:mt-24",
    plate: "inset-x-[11%] top-[14%] bottom-[10%]",
    ratio: "aspect-[3/4]",
    chips: "top-[52%] -right-1",
  },
  {
    card: "col-span-2 lg:col-span-4 mt-2 lg:mt-6",
    plate: "inset-x-[8%] top-[17%] bottom-[5%]",
    ratio: "aspect-[2/3]",
    chips: "bottom-[12%] -left-1",
  },
  {
    card: "col-span-2 lg:col-span-3 mt-10 lg:mt-20",
    plate: "inset-x-[10%] top-[13%] bottom-[7%]",
    ratio: "aspect-[3/4]",
    chips: "top-[38%] -right-1",
  },
];

export function SampleCard({
  product,
  index = 0,
  staggered = true,
}: {
  product: SampleProduct;
  index?: number;
  staggered?: boolean;
}) {
  const l = layouts[index % layouts.length];
  const cardClass = staggered ? l.card : "col-span-2 lg:col-span-3 mt-0";
  const plateClass = staggered ? l.plate : "inset-x-[8%] top-[14%] bottom-[6%]";
  const chipsClass = staggered ? l.chips : "top-[42%] -right-1";
  const ratio = staggered ? l.ratio : "aspect-[3/4]";
  const colors = product.colors ?? [];

  return (
    <motion.article
      initial={{ opacity: 0, y: 26 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.7, delay: (index % 3) * 0.08, ease: [0.16, 1, 0.3, 1] }}
      className={`sample-card relative ${cardClass}`}
    >
      <Link href={`/product/${product.slug}`} className="focusable block">
        <div className="relative">
          {/* the printed plate the sample is pinned to */}
          <div className={`absolute bg-paper-2 ring-1 ring-ink/10 ${plateClass}`} />

          {/* the cut sample, lifting out of the frame */}
          <div
            className={`sample-frame relative z-10 overflow-hidden shadow-[0_18px_34px_-24px_rgba(23,17,14,0.65)] ${ratio}`}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={product.image}
              alt={product.name}
              loading="lazy"
              className="h-full w-full object-cover object-center"
            />
          </div>

          {/* registration chips, pinned outside the plate */}
          <div className={`absolute z-20 flex gap-1.5 ${chipsClass}`}>
            {colors.slice(0, 3).map((c) => (
              <span
                key={c.name}
                title={c.name}
                className="block h-2.5 w-2.5 shadow-[0_0_0_1px_rgba(23,17,14,0.18)]"
                style={{ background: c.hex }}
              />
            ))}
          </div>
        </div>

        <div className="relative z-10 mt-4 flex items-start justify-between gap-3">
          <div>
            <h3 className="text-[13px] leading-tight font-semibold">
              {product.category} “{product.name.split(" ")[0]}”
            </h3>
            <p className="num mt-1 text-[13px] text-oxblood">{formatPrice(product.price)}</p>
          </div>
          <span className="label mt-0.5 text-stone">0{index + 1}</span>
        </div>
      </Link>

      {/* the pin — outside the link so it never navigates */}
      <div className="absolute top-1.5 right-1.5 z-30">
        <WishlistButton
          variant="chip"
          item={{
            slug: product.slug,
            name: product.name,
            category: product.category,
            price: product.price,
            image: product.image,
            sizes: [],
            colors: product.colors ?? null,
          }}
        />
      </div>
    </motion.article>
  );
}
