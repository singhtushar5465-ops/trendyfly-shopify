import Link from "next/link";
import type { Collection } from "@/data/site";

export function CollectionTiles({ collections }: { collections: Collection[] }) {
  const streetwear = collections.find((c) => c.slug === "streetwear") ?? collections[0];
  const tailoring =
    collections.find((c) => c.slug === "tailoring") ?? collections[1] ?? collections[0];
  const menu = ["New In", "Outerwear", "Knitwear", "Trousers", "Footwear"];

  return (
    <section id="collection" className="px-2 pt-2 md:px-3 md:pt-3">
      <div className="grid gap-2 md:grid-cols-2 md:gap-3">
        {/* tile one — the collection word, centred small */}
        <Link
          href={`/shop?c=${streetwear.slug}`}
          className="focusable group relative block overflow-hidden bg-leather"
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={streetwear.image}
            alt={`${streetwear.name} collection`}
            className="h-[70vh] w-full object-cover object-top transition-transform duration-[1200ms] ease-out group-hover:scale-[1.04]"
          />
          <div className="absolute inset-0 bg-ink/10 transition-colors group-hover:bg-ink/25" />
          <span className="slab absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[clamp(1.6rem,3.2vw,2.8rem)] text-paper-2">
            {streetwear.name}
          </span>
          <div className="absolute bottom-6 left-6">
            <span className="label bg-ink/70 px-3 py-2 text-paper-2">{streetwear.kicker} ↗</span>
          </div>
        </Link>

        {/* tile two — the floating index list */}
        <Link
          href={`/shop?c=${tailoring.slug}`}
          className="focusable group relative block overflow-hidden bg-stone"
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={tailoring.image}
            alt={`${tailoring.name} collection`}
            className="h-[70vh] w-full object-cover object-center transition-transform duration-[1200ms] ease-out group-hover:scale-[1.04]"
          />
          <div className="absolute inset-0 bg-ink/15 transition-colors group-hover:bg-ink/30" />
          <ul className="absolute top-1/2 left-1/2 flex -translate-x-1/2 -translate-y-1/2 flex-col items-center gap-3">
            {menu.map((item) => (
              <li key={item} className="transition-transform duration-500 group-hover:translate-x-1">
                <span className="label-lg block bg-ink/55 px-4 py-2 text-paper-2 backdrop-blur-[2px]">
                  {item}
                </span>
              </li>
            ))}
          </ul>
          <div className="absolute right-6 bottom-6">
            <span className="label bg-paper-2 px-3 py-2 text-ink">{tailoring.kicker} ↗</span>
          </div>
        </Link>
      </div>

      <div className="mx-auto mt-4 grid max-w-[1600px] gap-3 px-1 py-4 md:grid-cols-2 md:px-5">
        <p className="text-sm leading-relaxed text-stone md:max-w-[46ch]">{streetwear.blurb}</p>
        <p className="text-sm leading-relaxed text-stone md:max-w-[46ch] md:justify-self-end">
          {tailoring.blurb}
        </p>
      </div>
    </section>
  );
}
