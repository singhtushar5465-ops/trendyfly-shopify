/**
 * TRENDYFLY identity — drawn as vector paths, not an image.
 * The mark is a "TF" ligature: a full crossbar (the horizon line), a spine that
 * sweeps away into a tail (flight / the fly), and one floating arm (the F).
 * Reads at 16px, works filled in a single colour.
 */
export function LogoMark({
  className = "h-6 w-auto",
  title = "TRENDYFLY",
}: {
  className?: string;
  title?: string;
}) {
  return (
    <svg
      viewBox="0 0 56 48"
      className={className}
      role="img"
      aria-label={title}
      fill="currentColor"
      xmlns="http://www.w3.org/2000/svg"
    >
      <title>{title}</title>
      {/* crossbar — the horizon */}
      <path d="M2 5 H54 V14.4 H2 Z" />
      {/* spine with swept tail */}
      <path d="M21.4 14.4 H31.2 V28.6 C31.2 34.4 33.4 39.4 38.2 45.6 L27.6 45.6 C23.2 39.6 21.4 34.2 21.4 28.2 Z" />
      {/* the floating arm of the F */}
      <path d="M34.2 20.6 H52.6 V28 H34.2 Z" />
      {/* flight chip — the mark's spark */}
      <path d="M42.8 33.2 H52.6 V40.6 H42.8 Z" />
    </svg>
  );
}

/** Full lockup: vector mark + wordmark set in the display grotesque. */
export function Logo({
  className = "",
  markClass = "h-[18px] w-auto",
  wordClass = "text-[19px]",
}: {
  className?: string;
  markClass?: string;
  wordClass?: string;
}) {
  return (
    <span className={`inline-flex items-center gap-2 text-ink ${className}`}>
      <LogoMark className={markClass} />
      <span
        className={`slab leading-none ${wordClass}`}
        style={{ letterSpacing: "0.02em", fontWeight: 900 }}
      >
        Trendyfly
      </span>
    </span>
  );
}
