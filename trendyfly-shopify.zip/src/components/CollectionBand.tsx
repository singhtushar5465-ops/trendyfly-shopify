import Link from "next/link";
import { collectionBand } from "@/data/site";

export function CollectionBand() {
  return (
    <section className="relative overflow-hidden bg-leather">
      <div className="grid md:grid-cols-[minmax(0,1fr)_minmax(0,1.6fr)_minmax(0,1fr)]">
        <div className="relative hidden overflow-hidden md:block">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="images/hero-detail.jpg"
            alt=""
            aria-hidden="true"
            className="h-full w-full object-cover object-[60%_30%]"
          />
          <div className="absolute inset-0 bg-leather/35" />
        </div>

        <div className="grain relative flex flex-col items-center justify-center gap-8 px-6 py-20 text-center md:py-32">
          <span className="label text-paper-2/60">{collectionBand.kicker}</span>
          <h2 className="slab text-[clamp(3rem,9vw,7.5rem)] text-paper-2">{collectionBand.title}</h2>
          <Link
            href={collectionBand.buttonHref}
            className="focusable label-lg border border-paper-2/70 px-12 py-4 text-paper-2 transition-colors hover:bg-paper-2 hover:text-leather"
          >
            {collectionBand.buttonLabel}
          </Link>
          <p className="max-w-[34ch] text-sm leading-relaxed text-paper-2/70">{collectionBand.note}</p>
        </div>

        <div className="relative hidden overflow-hidden md:block">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="images/tile-tailoring.jpg"
            alt=""
            aria-hidden="true"
            className="h-full w-full object-cover object-[50%_25%]"
          />
          <div className="absolute inset-0 bg-leather/35" />
        </div>
      </div>
    </section>
  );
}
