"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useCart } from "@/components/CartProvider";
import { Logo } from "@/components/Logo";
import { HeartIcon } from "@/components/WishlistButton";
import { SearchOverlay } from "@/components/SearchOverlay";
import { useWishlist } from "@/components/WishlistProvider";
import { nav } from "@/data/site";

export function Header() {
  const { count, setOpen } = useCart();
  const { count: wishCount } = useWishlist();
  const [menu, setMenu] = useState(false);
  const [search, setSearch] = useState(false);

  // ⌘K / Ctrl+K opens search
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setSearch(true);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <>
      <header className="sticky top-0 z-30 border-b hairline bg-paper/95 backdrop-blur-sm">
        <div className="mx-auto grid max-w-[1600px] grid-cols-3 items-center px-5 py-4 md:px-8">
          <nav className="hidden items-center gap-7 md:flex">
            {nav.map((l) => (
              <Link key={l.label} href={l.href} className="label focusable link-underline">
                {l.label}
              </Link>
            ))}
          </nav>
          <button
            type="button"
            className="label focusable justify-self-start md:hidden"
            onClick={() => setMenu((v) => !v)}
            aria-expanded={menu}
          >
            {menu ? "Close" : "Menu"}
          </button>

          <Link href="/" className="focusable justify-self-center" aria-label="TRENDYFLY home">
            <Logo markClass="h-[17px] w-auto" wordClass="text-[18px]" />
          </Link>

          <div className="flex items-center justify-end gap-4 sm:gap-6">
            <button
              type="button"
              onClick={() => setSearch(true)}
              aria-label="Open search"
              className="label focusable link-underline"
            >
              Search
            </button>
            <Link href="/checkout" className="label focusable link-underline hidden lg:inline">
              Account
            </Link>
            <Link
              href="/wishlist"
              aria-label={`Wishlist, ${wishCount} saved`}
              className="label focusable link-underline flex items-center gap-1.5"
            >
              <HeartIcon filled={wishCount > 0} className="h-[15px] w-[15px]" />
              <span className={wishCount > 0 ? "num text-oxblood" : "num"}>{wishCount}</span>
            </Link>
            <button
              type="button"
              onClick={() => setOpen(true)}
              className="label focusable link-underline"
            >
              Bag (<span className="num">{count}</span>)
            </button>
          </div>
        </div>

        {menu && (
          <nav className="border-t hairline bg-paper-2 px-5 py-5 md:hidden">
            <ul className="space-y-4">
              <li>
                <button
                  type="button"
                  onClick={() => {
                    setMenu(false);
                    setSearch(true);
                  }}
                  className="display focusable block text-2xl"
                >
                  Search
                </button>
              </li>
              {nav.map((l) => (
                <li key={l.label}>
                  <Link
                    href={l.href}
                    onClick={() => setMenu(false)}
                    className="display focusable block text-2xl"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
              <li>
                <Link
                  href="/wishlist"
                  onClick={() => setMenu(false)}
                  className="display focusable block text-2xl"
                >
                  Wishlist ({wishCount})
                </Link>
              </li>
            </ul>
          </nav>
        )}
      </header>

      <SearchOverlay open={search} onClose={() => setSearch(false)} />
    </>
  );
}
